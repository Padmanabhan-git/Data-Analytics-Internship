# Titanic EDA Submission

Files included:
- train.csv
- EDA_Titanic.ipynb
- EDA_Report.pdf
- plots/

(Placeholder README recreated.)
