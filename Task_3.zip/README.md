# Task 3 DA - Dashboard Design Submission

This repository contains the deliverables for **Task 3 DA: Dashboard Design**.

**Contents**
- sales_financial_dataset.csv — synthetic sales & financial data (2021-2024, 2000 rows)
- mock_dashboard_overview.png — composite mock dashboard image (for visualization preview)
- timeseries_sales.png, timeseries_profit.png, bar_sales_region.png, pie_segment.png — individual charts
- Task3_Dashboard_Summary.pptx — PPT summary of the dashboard and insights
- README.md (this file)
- interview_qna.txt — answers to interview questions listed in the task

**How to reproduce in Power BI**
1. Open Power BI Desktop and click 'Get Data' → CSV and load `sales_financial_dataset.csv`.
2. Create calculated measures for Total Sales, Total Profit, Profit Margin and YoY Growth.
3. Build visuals: Cards, Line charts, Bar charts, Pie/Donut charts, and add slicers for interactivity.
4. Use bookmarks to create navigation and consistent theme settings for colors and formatting.

**Notes**
- Dataset is synthetic and created for learning/demo purposes.
- The dashboard included is a mock composite image representing how visuals would be arranged in Power BI.
