-- Q1_total_revenue_per_month
SELECT strftime('%Y-%m', order_date) AS month, SUM(quantity * unit_price) AS revenue FROM orders o JOIN order_items oi ON o.order_id = oi.order_id WHERE o.status = 'paid' GROUP BY month ORDER BY month;

-- Q2_top_customers_by_revenue
SELECT c.customer_id, c.first_name || ' ' || c.last_name AS customer_name, SUM(oi.quantity * oi.unit_price) AS total_spent FROM customers c JOIN orders o ON c.customer_id = o.customer_id JOIN order_items oi ON o.order_id = oi.order_id WHERE o.status = 'paid' GROUP BY c.customer_id ORDER BY total_spent DESC LIMIT 10;

-- Q3_avg_revenue_per_user_ARPU
SELECT ROUND( (SUM(oi.quantity * oi.unit_price) * 1.0) / COUNT(DISTINCT o.customer_id), 2) AS ARPU FROM orders o JOIN order_items oi ON o.order_id = oi.order_id WHERE o.status = 'paid';

-- Q4_category_performance
SELECT p.category, COUNT(DISTINCT o.order_id) AS orders_count, SUM(oi.quantity*oi.unit_price) AS revenue, AVG(oi.quantity*oi.unit_price) AS avg_order_value FROM products p JOIN order_items oi ON p.product_id = oi.product_id JOIN orders o ON o.order_id = oi.order_id WHERE o.status = 'paid' GROUP BY p.category ORDER BY revenue DESC;

-- Q5_view_recent_orders
CREATE VIEW IF NOT EXISTS recent_paid_orders AS SELECT o.order_id, o.customer_id, o.order_date, SUM(oi.quantity*oi.unit_price) AS order_total FROM orders o JOIN order_items oi ON o.order_id = oi.order_id WHERE o.status = 'paid' AND o.order_date >= datetime('now','-180 day') GROUP BY o.order_id;

-- Q6_subquery_repeat_customers
SELECT customer_id, COUNT(*) AS paid_orders FROM orders WHERE status='paid' GROUP BY customer_id HAVING paid_orders > 3 ORDER BY paid_orders DESC;

-- Q7_optimize_example_use_index
SELECT o.customer_id, COUNT(o.order_id) as cnt FROM orders o WHERE o.order_date >= date('2024-01-01') GROUP BY o.customer_id ORDER BY cnt DESC LIMIT 5;

